package view;

import servico.Maquina;

public class Main {



    public static void main(String []args) {
        Maquina maquina = new Maquina(2);

        //menu

        //opções

    }
}
